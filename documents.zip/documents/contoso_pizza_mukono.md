# 📍 Contoso Pizza – Mukono, Uganda 🇺🇬

**Description:**  
Set along the busy Jinja Road in Mukono town, Contoso Pizza offers a cozy, family-friendly environment with rustic décor and a welcoming garden patio. The menu features regional twists such as the "Groundnut Sauce Pizza" and the "Tilapia Flatbread," alongside traditional Mediterranean favorites. A popular weekend destination, the restaurant often hosts community events and outdoor movie nights.  

**Address:** Jinja Road, Mukono Town, Uganda  
**Opening Hours:**  
Mon–Sun: 12:00 PM – 9:00 PM  
**Contact:** +256 312 555 789 | mukono@contosopizza.com