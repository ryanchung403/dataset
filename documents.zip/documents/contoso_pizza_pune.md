# 📍 Contoso Pizza – Pune, India 🇮🇳

**Description:**  
In Pune’s vibrant Koregaon Park, Contoso Pizza offers a relaxed yet stylish setting with indoor greenery, rustic wooden décor, and open-air seating. The menu includes Pune-inspired dishes such as the "Misal Pav Pizza" and the "Spiced Corn & Cheese Flatbread." A favorite spot for students and young professionals, the restaurant also features live acoustic evenings on weekends.  

**Address:** Lane 7, Koregaon Park, Pune, India 411001  
**Opening Hours:**  
Mon–Sun: 11:30 AM – 10:30 PM  
**Contact:** +91 20 2345 6789 | pune@contosopizza.com