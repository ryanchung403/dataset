# 📍 Contoso Pizza – Perth, WA, Australia

**Description:**  
Craving a cracking good feed? Swing by Contoso Pizza, Perth’s go-to spot for top-tier takeaway pizza. We’re all about bold Aussie flavours, fresh WA ingredients, and wood-fired goodness done right. Whether you're after a classic Pepperoni, a smoky BBQ chook, or something a bit fancy like our bush tomato & feta special, we’ve got your pizza night sorted. No dine-in, no fuss—just quick, quality takeaway that hits the spot every time. Order ahead online or give us a bell!

**Address:** 105 Lake Street, Northbridge, WA 6003
**Opening Hours:**  
Mon–Wed: 4:00 PM – 9:30 PM
Thu–Sat: 4:00 PM – 10:30 PM
Sun: 4:00 PM – 9:00 PM
**Contact:** (08) 6244 9876 | perth@contosopizza.com
