# 📍 Contoso Pizza – Taipei, Taiwan

**Description:**
Contoso Pizza's Taipei location brings authentic Italian pizza craftsmanship to Taiwan's vibrant food scene. Located in the heart of the city, our restaurant combines traditional wood-fired ovens with locally-sourced ingredients, offering both classic Neapolitan pizzas and innovative Asian-fusion creations. We pride ourselves on creating a warm, welcoming atmosphere where customers can enjoy premium quality pizza with exceptional service.

**Address:** No. 123, Dunnan Road, Daan District, Taipei 106, Taiwan

**Opening Hours:**
- **Monday to Friday:** 11:00 AM – 10:00 PM
- **Saturday & Sunday:** 10:00 AM – 11:00 PM
- **Public Holidays:** 10:00 AM – 10:00 PM

**Contact:** 
- **Phone:** +886-2-2771-8888
- **Email:** taipei@contosopizza.tw